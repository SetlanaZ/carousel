from flask import Flask
from flask import url_for

app = Flask(__name__)


@app.route('/')
def index():
    return "Миссия Колонизация Марса"


@app.route('/index')
def countdown():
    return 'И на Марсе будут яблони цвести!'


@app.route('/promotion')
def promotion():
    promotion_list = (['Человечество вырастает из детства.', 'Человечеству мала одна планета.',
                      'Мы сделаем обитаемыми безжизненные пока планеты.', 'И начнем с Марса!', 'Присоединяйся!'])
    return '</br>'.join(promotion_list)


@app.route('/image_mars')
def image():
    return """<!doctype html>
                    <html lang="en">
                      <head>
                        <meta charset="utf-8">
                        <title>Привет, Марс!</title>
                      </head>
                      <body>
                        <h1>Жди нас, Марс!</h1>
                        <img src="/static/img/mars.jpg" alt="здесь должна была быть картинка, но не нашлась">
                        <p>Вот она какая, красная планета.<p>
                      </body>
                    </html>"""


@app.route('/promotion_image')
def promotion_image():
    return f"""<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <link rel="stylesheet" type="text/css" href="{url_for('static', filename='css/style.css')}" />
                    <link rel="stylesheet" 
                    href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
                    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" 
                    crossorigin="anonymous">
                    <title>Колонизация</title>
                  </head>
                  <body>
                    <h1>Жди нас, Марс!</h1>
                    <img src="/static/img/mars.jpg" alt="здесь должна была быть картинка, но не нашлась">
                    
                    <div class="alert alert-dark" role="alert">
                    Человечество вырастает из детства.
                    </div>
                    <div class="alert alert-success" role="alert">
                    Человечеству мала одна планета.
                    </div>
                    <div class="alert alert-secondary" role="alert">
                    Мы сделаем обитаемыми безжизненные пока планеты.
                    </div>
                    <div class="alert alert-warning" role="alert">
                    И начнем с Марса!
                    </div>
                    <div class="alert alert-danger" role="alert">
                    Присоединяйся!
                    </div>
                  </body>
                </html>"""


@app.route('/choice/<planet_name>')
def greeting(planet_name):
    return '''<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                   <link rel="stylesheet"
                   href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
                   integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
                   crossorigin="anonymous">
                    <title>Варианты выбора</title>
                  </head>
                  <body>
                    <div class="alert alert-light text-body">
                    <h1>Мое предложение: {}</h1>
                    </div>
                    <div class="alert alert-light text-body">
                    <h2>Эта планета близка к земле;</h2>
                    </div>
                    <div align="left" class="alert alert-success" role="alert">
                    <h2>На ней много необходимых ресурсов;</h2>
                    </div>
                    <div align="left" class="alert alert-secondary" role="alert">
                    <h2>На ней есть вода и атмосфера;</h2>
                    </div>
                    <div align="left" class="alert alert-warning" role="alert">
                    <h2>На ней есть небольшое магнитное поле;</h2>
                    </div>
                    <div align="left" class="alert alert-danger" role="alert">
                    <h2>Наконец, она просто красива!</h2>
                    </div>
                  </body>
                </html>'''.format(planet_name)


@app.route('/results/<nickname>/<int:level>/<float:rating>')
def three_params(nickname, level, rating):
    return '''<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet"
                    href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
                    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
                    crossorigin="anonymous">
                    <title>Результаты</title>
                  </head>
                  <body>
                    <div class="alert alert-light text-body">
                    <h1>Результаты отбора</h1>
                    </div>
                    <div class="alert alert-light text-body">
                    <h2>Претендента на участие в миссии {}:</h2>
                    </div>
                    <div align="left" class="alert alert-success" role="alert">
                    <h3>Поздравляем! Ваш рейтинг после {} этапа отбора</h3>
                    </div>
                    <div class="alert alert-light text-body">
                    <h3>составляет {}!</h32>
                    </div>
                    <div align="left" class="alert alert-warning" role="alert">
                    <h2>Желаем удачи!</h2>
                    </div>
                  </body>
                </html>'''.format(nickname, level, rating)


@app.route('/carousel')
def carousel():
    return '''<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet"
                    href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
                    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
                    crossorigin="anonymous">
                    <title>Пейзажи марса</title>
                  </head>
                  <body>
                  <div align="center">
                  <h1>Пейзажи марса</h1>
                  </div>
                    <div id="carousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div align="center" class="carousel-item active">
                          <img class="w-50 p-3" src="/static/img/mars1.jpg" alt="First slide">
                    </div>
                    <div align="center" class="carousel-item">
                          <img class="w-50 p-3" src="/static/img/mars2.jpg" alt="Second slide">
                    </div>
                    <div align="center" class="carousel-item">
                          <img class="w-50 p-3" src="/static/img/mars3.jpg" alt="Third slide">
                        </div>
                    </div>
                  <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
                <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
                </body>
                </html>'''


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')

